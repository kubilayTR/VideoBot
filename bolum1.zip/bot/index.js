////////////// Modüller \\\\\\\\\\\\\\\\
const fs = require("fs")
const Discord = require('discord.js');
const { Client, Intents , Collection,  Util, MessageEmbed, Permissions, MessageActionRow, MessageButton} = require('discord.js');
const synchronizeSlashCommands = require('./util/discord-sync-commands');
const figlet = require('figlet');
////////////// Modüller \\\\\\\\\\\\\\\\

/////////////////////////////// Sistemler \\\\\\\\\\\\\\\\\\
const ayarlar = require('./ayarlar.json')
const client = new Client({ intents: [
Intents.FLAGS.GUILDS,
Intents.FLAGS.GUILD_MESSAGES,
Intents.FLAGS.GUILD_VOICE_STATES,
Intents.FLAGS.GUILD_MESSAGE_REACTIONS
]});
client.login(ayarlar.token)
const {kubitdb} = require('kubitdb')
const db = new kubitdb("datalar/index")
/////////////////////////////// Sistemler \\\\\\\\\\\\\\\\\\

/////////////////////////////// Komutlar \\\\\\\\\\\\\\\\\\\\
client.slashcommands = new Collection();
fs.readdir("./komutlar/", (_err, files) => {
files.forEach((file) => {if (!file.endsWith(".js")) return;
let props = require(`./komutlar/${file}`);
let commandName = file.split(".")[0];
client.slashcommands.set(commandName, {name: commandName,...props});
console.log(`Slash Yüklenen komutu: ${commandName}`);});
synchronizeSlashCommands(client, client.slashcommands.map((c) => ({
name: c.name,description: c.description, options: c.options,type: 'CHAT_INPUT'})), {debug: true})});
client.on('interactionCreate', async interaction => {
if (!interaction.isCommand()) return;
if(!interaction.type == "GUILD_TEXT") return interaction.reply({ content:"Üzgünüm (/) Komutlarını Dm Üzerinde Kullanamazsın!"})
const command = client.slashcommands.get(interaction.commandName);
if (!command) return void interaction.reply({
content: `\`${interaction.commandName}\` Komutunuzda bir hata oluştu, lütfen bunu bildirin discord.gg/4Xpwwz6pgN`,
ephemeral: true});
command.run(client, interaction)})
/////////////////////////////// Komutlar \\\\\\\\\\\\\\\\\\\\

/////////////////////////////// Bot hazır olduğunda \\\\\\\\\\\\\\\\\\\\\
client.on("ready",()=>{
client.user.setPresence({activities:[{name:ayarlar.activities}]})
client.user.setStatus(ayarlar.status)
figlet("Bot hazır",function(a,b){console.log(b)})
})
/////////////////////////////// Bot hazır olduğunda \\\\\\\\\\\\\\\\\\\\\

client.on("message", (message)=>{
db.ekle("xp"+message.author.id,1)

if(message.content === "mesajımkac") {
    message.channel.send(`${message.author.username}, senin mesajın ${db.al("xp"+message.author.id)}`)
}
})